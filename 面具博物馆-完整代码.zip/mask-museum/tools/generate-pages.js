#!/usr/bin/env node
/* ============================================================
   mask-museum / tools/generate-pages.js
   ------------------------------------------------------------
   批量生成站点静态页面（全部为可直接编辑的 HTML，运行一次即可）：
   1. 21 个面具子页面  pages/masks/<key>-{text,gallery,model}.html
   2. 4 个历史展厅子页面 pages/history/{origin,process,meaning,conclusion}.html
   运行方式：  node tools/generate-pages.js
   说明：
   - 功能页（game/story/quiz/hall）与 index.html 为手写，本脚本不覆盖。
   - 子页面统一使用「根相对路径 + <base href="../../">」：
     本地 file:// 打开时靠 <base> 定位到站点根；
     发布到 doubao-html 时运行时会注入应用根 <base> 并覆盖本 base，
     同样按应用根解析，两端路径都正确。
   - 生成后再跑一次会覆盖对应文件，请知悉。
   ============================================================ */
"use strict";
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "..");

/* ---------- 面具数据（与 js/data/masks.js 保持一致，便于独立生成） ---------- */
const MASKS = [
  { key: "wemba",   name: "温巴面具", color: "蓝 + 白", galleryN: 6 },
  { key: "shouwen", name: "黑面具", color: "黑", galleryN: 6 },
  { key: "yunlei",  name: "白面具", color: "白", galleryN: 6 },
  { key: "liujin",  name: "黄面具", color: "黄", galleryN: 6 },
  { key: "moying",  name: "绿面具", color: "绿", galleryN: 6 },
  { key: "chiyan",  name: "红面具", color: "赤", galleryN: 6 },
  { key: "xuanqing",name: "蓝面具", color: "蓝", galleryN: 6 }
];

const VIEWS = [
  { key: "text",    label: "文字介绍" },
  { key: "gallery", label: "图片展示" },
  { key: "model",   label: "建模展示" }
];

/* 金色面具 favicon（SVG data URI） */
const FAVICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Cpath fill='%23b28a3e' d='M32 8C18 8 8 16 8 27c0 5 2 10 5 14l3 12 16-4 16 4 3-12c3-4 5-9 5-14C56 16 46 8 32 8z'/%3E%3C/svg%3E";

/* 字体：使用系统衬线栈（见 css/base.css --font-serif），不依赖外链 */
const FONTS = "";

/* 子页面相对站点根（pages/<某>/ 深两层） */
const BASE = "../../";

/* ---------- HTML 骨架组装 ---------- */
function head(title) {
  return `<!DOCTYPE html>
<!-- ============================================================
  mask-museum 子页面（由 tools/generate-pages.js 生成）
  页面：${title}
  修改方法：直接编辑本文件即可；换图片/补充文字均在此操作。
  路径说明：本页使用根相对路径 + <base href="${BASE}">，
  本地打开与在线发布均能正确解析资源。
============================================================ -->
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <base href="${BASE}">
  <title>${title}</title>
  ${FONTS}
  <link rel="stylesheet" href="css/base.css">
  <link rel="stylesheet" href="css/mask-page.css">
  <link rel="icon" href="${FAVICON}">
</head>
<body>
`;
}

function foot() {
  return `  <footer class="site-footer">面具博物馆 · 占位内容待补充</footer>
  <script src="js/common.js"></script>
</body>
</html>
`;
}

/* 顶部返回栏：maskPage 为同面具三视图切换链接数组（根相对路径） */
function topbar(backHref, title, navLinks) {
  const nav = navLinks.map((l) =>
    `        <a href="${l.href}"${l.active ? ' class="is-active"' : ""}>${l.label}</a>`
  ).join("\n");
  return `  <!-- 顶部返回栏 -->
  <header class="topbar">
    <div class="topbar__inner">
      <a class="topbar__back" href="${backHref}">&#8592; 返回主厅</a>
      <div class="topbar__title">${title}</div>
      <nav class="topbar__nav" aria-label="同面具视图切换">
${nav}
      </nav>
    </div>
  </header>
`;
}

/* ============================================================
   1. 面具子页面
   ============================================================ */
function maskNavLinks(mask, currentView) {
  return VIEWS.map((v) => ({
    href: `pages/masks/${mask.key}-${v.key}.html`,
    label: v.label,
    active: v.key === currentView
  }));
}

function maskTextPage(mask) {
  const nav = maskNavLinks(mask, "text");
  const viewLabel = "文字介绍";
  const other = VIEWS.filter((v) => v.key !== "text");
  const actions = other.map((v) =>
    `      <a class="btn" href="pages/masks/${mask.key}-${v.key}.html">查看${v.label}</a>`
  ).join("\n");

  return head(`${mask.name} · ${viewLabel}`) +
    topbar(`index.html#hall`, `${mask.name} <small>· ${viewLabel}</small>`, nav) +
    `  <main class="page-wrap">
    <!-- 页面主标题 -->
    <div class="page-title">
      <h1>${mask.name}</h1>
      <div class="page-sub">${viewLabel}</div>
    </div>

    <div class="content-card">
      <h2>关于「${mask.name}」</h2>
      <!-- 占位：在此补充该面具的文字介绍 -->
      <p>此处为${mask.name}的文字介绍，后续补充详细内容。</p>
      <p>可以分几个段落：起源传说、造型寓意、使用场景、文化价值等。</p>

      <!-- 可扩展折叠区：更多细节 -->
      <details class="acc">
        <summary>更多细节</summary>
        <div class="acc-body">
          <p>此处可放置该面具的更多细节（工艺、材质、象征意义等）。</p>
        </div>
      </details>

      <!-- 占位：代表图，上传后替换为正式图片
           建议尺寸 800x600，格式 JPG/PNG/WebP，放入 assets/images/ -->
      <div class="mask-hero-ph ph-img">
        <span>代表图待上传 · 建议 800x600 · JPG/PNG/WebP</span>
      </div>
    </div>

    <div class="page-actions">
      <a class="btn" href="index.html#hall">返回主厅</a>
${actions}
    </div>
  </main>
` + foot();
}

function maskGalleryPage(mask) {
  const nav = maskNavLinks(mask, "gallery");
  const viewLabel = "图片展示";

  const cells = Array.from({ length: mask.galleryN }, (_, i) => {
    const n = String(i + 1).padStart(2, "0");
    return `      <!-- 占位：上传后替换 src，命名如 ${mask.key}-${n}.jpg -->
      <figure class="g-cell">
        <img class="ph-img js-lightbox-trigger"
             src="assets/images/placeholder.svg"
             alt="${mask.name} 图片 ${n}">
      </figure>`;
  }).join("\n");

  return head(`${mask.name} · ${viewLabel}`) +
    topbar(`index.html#hall`, `${mask.name} <small>· ${viewLabel}</small>`, nav) +
    `  <main class="page-wrap">
    <div class="page-title">
      <h1>${mask.name}</h1>
      <div class="page-sub">${viewLabel}</div>
    </div>

    <!-- 图片网格（点击可放大，灯箱由 js/common.js 实现） -->
    <section class="gallery-grid" aria-label="${mask.name}图片">
${cells}
    </section>

    <div class="note">图片待上传：建议 JPG / PNG / WebP，单张不超过 2MB，命名如 ${mask.key}-01.jpg，放入 assets/images/ 后替换本页对应 src。</div>

    <div class="page-actions">
      <a class="btn" href="index.html#hall">返回主厅</a>
      <a class="btn" href="pages/masks/${mask.key}-text.html">查看文字介绍</a>
      <a class="btn" href="pages/masks/${mask.key}-model.html">查看建模展示</a>
    </div>
  </main>
` + foot();
}

function maskModelPage(mask) {
  const nav = maskNavLinks(mask, "model");
  const viewLabel = "建模展示";

  return head(`${mask.name} · ${viewLabel}`) +
    topbar(`index.html#hall`, `${mask.name} <small>· ${viewLabel}</small>`, nav) +
    `  <main class="page-wrap">
    <div class="page-title">
      <h1>${mask.name}</h1>
      <div class="page-sub">${viewLabel}</div>
    </div>

    <!-- 3D 模型查看器占位（后续可接入 <model-viewer> 或 Three.js） -->
    <div class="model-viewer-ph">
      <div class="m-icon">&#9670;</div>
      <span>3D 模型占位</span>
    </div>

    <!-- 视频播放器占位（无 src，等待上传后填写） -->
    <div class="video-ph">
      <span>&#9654;</span>
      <span>视频待上传 · 建议 MP4 · 1920x1080</span>
    </div>

    <div class="note">模型建议上传 GLB / GLTF 格式（放入 assets/models/），视频建议 MP4（放入 assets/videos/）。</div>

    <div class="page-actions">
      <a class="btn" href="index.html#hall">返回主厅</a>
      <a class="btn" href="pages/masks/${mask.key}-text.html">查看文字介绍</a>
      <a class="btn" href="pages/masks/${mask.key}-gallery.html">查看图片展示</a>
    </div>
  </main>
` + foot();
}

/* ============================================================
   2. 历史展厅子页面
   ============================================================ */
const HIST = [
  { key: "origin",     name: "发展起源", sub: "面具从何而来" },
  { key: "process",    name: "发展过程", sub: "千年的流变" },
  { key: "meaning",    name: "历史意义", sub: "面具背后的文化" },
  { key: "conclusion", name: "高大上结语", sub: "面具博物馆的愿景" }
];

function histPage(item) {
  return head(`${item.name} · 历史展厅`) +
    `  <!-- 顶部返回栏：返回历史展厅 -->
  <header class="topbar">
    <div class="topbar__inner">
      <a class="topbar__back" href="pages/history/hall.html">&#8592; 返回展厅</a>
      <div class="topbar__title">历史展厅 <small>· ${item.name}</small></div>
      <nav class="topbar__nav" aria-label="历史展厅导航">
        <a href="index.html#hall">返回主厅</a>
      </nav>
    </div>
  </header>
  <main class="page-wrap">
    <div class="page-title">
      <h1>${item.name}</h1>
      <div class="page-sub">${item.sub}</div>
    </div>

    <div class="content-card">
      <h2>${item.name}</h2>
      <!-- 占位：在此补充「${item.name}」的详细内容 -->
      <p>此处为${item.name}的详细内容，后续补充。</p>
      <p>可包含文字说明、配图、时间线等。</p>
    </div>

    <div class="page-actions">
      <a class="btn" href="pages/history/hall.html">返回历史展厅</a>
      <a class="btn" href="index.html#hall">返回主厅</a>
    </div>
  </main>
` + foot();
}

/* ---------- 写出所有文件 ---------- */
function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function write(file, content) {
  const p = path.join(ROOT, file);
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, content, "utf8");
  console.log("写入", file);
}

function main() {
  for (const m of MASKS) {
    write(`pages/masks/${m.key}-text.html`, maskTextPage(m));
    write(`pages/masks/${m.key}-gallery.html`, maskGalleryPage(m));
    write(`pages/masks/${m.key}-model.html`, maskModelPage(m));
  }
  for (const h of HIST) {
    write(`pages/history/${h.key}.html`, histPage(h));
  }
  console.log("\n完成：已生成 " + (MASKS.length * 3 + HIST.length) + " 个静态页面。");
}

main();
