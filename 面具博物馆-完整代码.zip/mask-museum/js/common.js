/* ============================================================
   mask-museum / js/common.js
   ------------------------------------------------------------
   所有页面共用的基础交互：
   1. 触摸设备：用 touchstart 模拟 hover（卡片添加 .is-hover）
   2. 图片灯箱（点击放大 / ESC 关闭）
   ============================================================ */

(function () {
  "use strict";

  /* ---------- 1. 触摸设备 hover 模拟 ---------- */
  const isTouch = window.matchMedia && window.matchMedia("(hover: none)").matches;
  if (isTouch) {
    document.addEventListener("touchstart", function (e) {
      const card = e.target.closest(".mask-card, .sec-card, .stage-btn, .hist-card");
      if (!card) return;
      document.querySelectorAll(".mask-card.is-hover, .sec-card.is-hover, .stage-btn.is-hover, .hist-card.is-hover")
        .forEach(function (el) { if (el !== card) el.classList.remove("is-hover"); });
      card.classList.toggle("is-hover");
    }, { passive: true });
  }

  /* ---------- 2. 灯箱 ---------- */
  let lightbox = null;
  function ensureLightbox() {
    if (lightbox) return lightbox;
    lightbox = document.createElement("div");
    lightbox.className = "lightbox";
    lightbox.innerHTML =
      '<img class="lightbox__img" alt="放大预览">' +
      '<button class="lightbox__close" aria-label="关闭">&times;</button>';
    document.body.appendChild(lightbox);

    const close = function () {
      lightbox.classList.remove("is-open");
      lightbox.querySelector(".lightbox__img").removeAttribute("src");
    };
    lightbox.addEventListener("click", function (e) {
      if (e.target !== lightbox.querySelector(".lightbox__img")) close();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
    return lightbox;
  }

  function bindLightbox(scope) {
    const imgs = scope.querySelectorAll("img.js-lightbox-trigger");
    imgs.forEach(function (img) {
      img.addEventListener("click", function () {
        const lb = ensureLightbox();
        lb.querySelector(".lightbox__img").src = img.src;
        lb.classList.add("is-open");
      });
    });
  }

  /* 页面加载后自动给所有带触发类的图片绑定灯箱 */
  document.addEventListener("DOMContentLoaded", function () {
    bindLightbox(document);
  });

  window.MaskUI = window.MaskUI || {};
  window.MaskUI.bindLightbox = bindLightbox;
})();
