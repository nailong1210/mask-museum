/* ============================================================
   mask-museum / js/curtain.js  （仅用于 index.html）
   ------------------------------------------------------------
   1. 揭幕按钮：触发帷幕左右滑出 + 标题淡出 + 主厅淡入
   2. 返回主厅：#hall 锚点 → 跳过入场动画，直接进入主厅
   3. 数据驱动生成：面具卡片环形放射布局（中心徽章 + 7 卡环绕，
      hover 浮现三选项）；四大板块卡片为静态 HTML，不再生成。
   ============================================================ */

(function () {
  "use strict";

  /* ============================================================
     一、入场帷幕动画（#hall 锚点直接跳过）
     ============================================================ */
  function initCurtain() {
    const curtain = document.getElementById("curtain");
    const hall = document.querySelector(".hall");
    const openBtn = document.getElementById("curtain-open");

    if (!curtain || !hall || !openBtn) return;

    // 子页面「返回主厅」携带 #hall 锚点：跳过帷幕，直接显示主厅
    if (window.location.hash === "#hall") {
      curtain.classList.add("is-open", "is-hidden");
      hall.classList.add("is-show", "is-immediate");
      return;
    }

    openBtn.addEventListener("click", function () {
      curtain.classList.add("is-open");      // 帷幕左右滑出
      hall.classList.add("is-show");          // 主厅延迟淡入
      window.setTimeout(function () {
        curtain.classList.add("is-hidden");   // 动画结束后隐藏帷幕层
      }, 1700);
    });
  }

  /* ============================================================
     二、面具卡片环形放射布局（数据驱动）
     ------------------------------------------------------------
     结构：
       .mask-ring
         ├─ .mask-ring__badge   中心徽章（面具博物馆 · 七面·千相）
         └─ .mask-ring__item ×7 环形定位节点（--i: 0..6，CSS 按角度分布）
              └─ .mask-card     卡片（hover 上浮 + 三选项浮出）
     ============================================================ */
  function initMaskCards() {
    const ring = document.querySelector(".mask-ring");
    if (!ring) return;

    const cardHTML = function (m) {
      // 面具图片：图标区显示对应图片（背景图由 css/index.css 的 --key 类提供，
      // 图片文件放在 assets/images/<key>.jpg；发布扫描只认 CSS url()，故不用 JS 拼 src）
      const opts = VIEWS.map(function (v) {
        return '<a href="' + v.file(m.key) + '">' + v.label + "</a>";
      }).join("");
      return (
        '<article class="mask-card">' +
          '<div class="mask-card__icon mask-card__icon--' + m.key + '" aria-label="' + m.name + '"></div>' +
          '<h3 class="mask-card__name">' + m.name + "</h3>" +
          '<div class="mask-card__color">' + m.color + "</div>" +
          // 悬停浮现的选项组（浮出层，由 css/index.css 控制显示）
          '<div class="mask-card__opts">' + opts + "</div>" +
        "</article>"
      );
    };

    // 中心徽章
    const badge =
      '<div class="mask-ring__badge">' +
        '<div class="badge-icon">面</div>' +
        "<h2>面具博物馆</h2>" +
        "<p>七面 · 千相</p>" +
      "</div>";

    // 七个卡片（--i 供 CSS 环形定位：i × 51.4286°）
    const items = MASKS.map(function (m, i) {
      return (
        '<div class="mask-ring__item" style="--i:' + i + '">' + cardHTML(m) + "</div>"
      );
    }).join("");

    ring.innerHTML = badge + items;

    // 依次淡入上移（每张延迟 0.08s 递增）
    const nodes = ring.querySelectorAll(".mask-ring__badge, .mask-ring__item");
    nodes.forEach(function (node, i) {
      window.setTimeout(function () {
        node.classList.add("is-in");
      }, 120 + i * 80);
    });
  }

  /* ============================================================
     三、板块入口卡片
     说明：四个板块卡片已静态写入 index.html（便于直接编辑与
     替换原创 IP 配图），本函数不再生成。保留占位注释以防回退。
     ============================================================ */
  /* function initSectionCards() { ... } 已停用 */

  /* ---------- 启动 ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    initCurtain();
    initMaskCards();
  });
})();
