/* ============================================================
   mask-museum / js/data/masks.js
   ------------------------------------------------------------
   面具数据源（单一定义，主页卡片与子页面导航共同引用）。
   说明：
   - key       : 用作文件名片段，如 wemba -> wemba-text.html
   - name      : 面具名称
   - color     : 颜色描述（展示在卡片上）
   - palette   : 该面具专属点缀色（供卡片图标使用，可选）
   - galleryN  : 图片展示页默认占位图数量
   后续替换图片/补充内容，只需要改这里的 name/color/palette，
   或直接编辑对应 pages/masks/*.html 文件即可。
   ============================================================ */

const MASKS = [
  {
    key: "wemba",
    name: "温巴面具",
    color: "蓝 + 白",
    palette: "#7f9dc0",
    galleryN: 6
  },
  {
    key: "shouwen",
    name: "黑面具",
    color: "黑",
    palette: "#a67c1e",
    galleryN: 6
  },
  {
    key: "yunlei",
    name: "白面具",
    color: "白",
    palette: "#6fa896",
    galleryN: 6
  },
  {
    key: "liujin",
    name: "黄面具",
    color: "黄",
    palette: "#c0843c",
    galleryN: 6
  },
  {
    key: "moying",
    name: "绿面具",
    color: "绿",
    palette: "#7c7466",
    galleryN: 6
  },
  {
    key: "chiyan",
    name: "红面具",
    color: "赤",
    palette: "#b06048",
    galleryN: 6
  },
  {
    key: "xuanqing",
    name: "蓝面具",
    color: "蓝",
    palette: "#4f8494",
    galleryN: 6
  }
];

/* 三个视图的元信息（中文名 + 相对站点根的文件名） */
const VIEWS = [
  { key: "text",    label: "文字介绍", file: (k) => `pages/masks/${k}-text.html` },
  { key: "gallery", label: "图片展示", file: (k) => `pages/masks/${k}-gallery.html` },
  { key: "model",   label: "建模展示", file: (k) => `pages/masks/${k}-model.html` }
];

/* 工具：按 key 查找面具 */
function findMask(key) {
  return MASKS.find((m) => m.key === key) || MASKS[0];
}
