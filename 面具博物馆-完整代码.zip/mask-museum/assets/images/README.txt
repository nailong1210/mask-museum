mask-museum / assets / images
=============================
图片资源目录（正式图片请放入本目录，替换 HTML 中的占位 src）。

建议规格：
- 格式：JPG / PNG / WebP
- 尺寸：800x600 或 1200x800（代表图 / 配图）
- 单张大小：不超过 2MB（图片展示页灯箱需求）
- 命名：与面具 key 对应，如 wemba-01.jpg、wemba-02.jpg ...

占位图（可保留或删除）：
- placeholder.svg       全局占位图（明亮版面具剪影）
- board-game.svg         板块卡：养成小游戏 配图（替换为原创 IP 小人）
- board-story.svg        板块卡：文字游戏 配图
- board-quiz.svg         板块卡：生成你的面具 配图
- board-history.svg      板块卡：历史展厅 配图

替换方法：
- 板块配图：替换 js/curtain.js 中 sections 数组的 img 字段
- 文字介绍页：替换 .mask-hero-ph 区域（建议直接用 <img> 替换占位 div）
- 图片展示页：替换 .gallery-grid 内每张 <img> 的 src，并删掉对应注释
