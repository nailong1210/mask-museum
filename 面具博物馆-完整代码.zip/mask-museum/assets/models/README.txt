mask-museum / assets / models
=============================
3D 模型资源目录（建模展示页的 3D 模型占位使用）。

建议规格：
- 格式：GLB / GLTF（也可用 gltf + bin 组合）
- 命名：与面具 key 对应，如 wemba.glb

集成方式（后续步骤）：
- 方式一：引入 <model-viewer>（Web Component）
- 方式二：使用 Three.js 加载
本框架先在 .model-viewer-ph 占位，后续在此容器内嵌入模型。
