mask-museum / assets / ppt
==========================
PPT 资源目录（文字游戏页使用）。

建议规格：
- 格式：PPTX
- 命名：story.pptx（对应 pages/story/story.html 中的链接）

替换方法：
- 用你的正式 PPT 覆盖本文件（保持同名 story.pptx），
  或修改 pages/story/story.html 中 <a href="assets/ppt/story.pptx"> 指向你的文件。
- 浏览器对 .pptx 通常直接下载或在新窗口打开。
