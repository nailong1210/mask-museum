mask-museum / assets / videos
=============================
视频资源目录（建模展示页的视频占位 <video> 使用）。

建议规格：
- 格式：MP4（H.264）
- 分辨率：1920x1080（16:9）
- 命名：与面具 key 对应，如 wemba-model.mp4

替换方法：
- 编辑 pages/masks/<key>-model.html，在 .video-ph 内放入
  <video controls src="assets/videos/wemba-model.mp4"></video>
