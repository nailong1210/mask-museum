# 面具博物馆 · MASK MUSEUM

明亮象牙白 + 暖金点缀的面具主题静态网站（入场帷幕为深色仪式感）。
纯 HTML / CSS / JS 搭建，无需后端、无需构建工具。**双击 `index.html` 即可运行。**

## 目录结构

```
mask-museum/
├── index.html                  # 入口：深色入场帷幕 + 明亮主厅
├── css/
│   ├── base.css                # 全局变量（明亮配色）、重置、返回栏、页脚、通用组件
│   ├── index.css               # 帷幕 + 主厅（面具卡片、板块大图卡片）
│   └── mask-page.css           # 面具子页面与功能页样式
├── js/
│   ├── data/masks.js           # 七个面具的数据源（改这里即可改卡片）
│   ├── common.js               # 触摸 hover、图片灯箱
│   └── curtain.js              # 揭幕动画 + 面具/板块卡片数据驱动生成
├── pages/
│   ├── masks/                  # 21 个面具子页面（7 面具 × 3 视图）
│   │   ├── <key>-text.html     # 文字介绍
│   │   ├── <key>-gallery.html  # 图片展示（灯箱）
│   │   └── <key>-model.html    # 建模展示（3D / 视频占位）
│   ├── game/nurture.html       # 养成小游戏（#game-container 待粘贴）
│   ├── story/story.html        # 文字游戏（链接本地 PPT）
│   ├── quiz/quiz.html          # 生成你的面具（#quiz-container 待粘贴）
│   └── history/
│       ├── hall.html           # 历史展厅导航
│       ├── origin.html         # 发展起源
│       ├── process.html        # 发展过程
│       ├── meaning.html        # 历史意义
│       └── conclusion.html     # 高大上结语
├── assets/
│   ├── images/                 # 正式图片 + 板块占位插画（board-*.svg）
│   ├── videos/                 # MP4 视频
│   ├── models/                 # GLB / GLTF 3D 模型
│   └── ppt/                    # story.pptx 文字游戏 PPT
└── tools/generate-pages.js     # （可选）重新生成面具子页面的脚本
```

## 交互说明

- **入场**：首次打开网站，点击「揭幕」，帷幕左右滑出（1.6s），主厅淡入。
- **返回主厅**：子页面点「返回主厅」会跳转到 `index.html#hall`，**跳过入场动画**，直接展示面具环 + 四大板块（仅第一次打开网站时播放入场动画）。
- **面具卡片（环形放射布局）**：页面中心为「面具博物馆 · 七面·千相」徽章，7 张面具卡片环绕分布，每张卡片的圆形图标显示对应面具实拍图片（assets/images/<key>.jpg，替换图片同名覆盖即可）；鼠标悬停 → 卡片上浮、浮现「文字介绍 / 图片展示 / 建模展示」三个选项块，点击进入对应子页。手机端自动降级为网格布局（不挤压卡片）。
- **板块大卡**：养成小游戏 / 文字游戏 / 生成你的面具 / 历史展厅，每张卡片带大图位（当前为占位插画，替换为你的原创 IP）+ 图文占位行。
- **3D 建模展示**：六个面具建模页均已接入 Three.js 三维模型（黑 / 白 / 绿 / 红 / 黄 / 蓝面具，可拖拽旋转、滚轮缩放）。
- **文字游戏**：已接入《文成公主》沉浸式文字游戏（pages/story/wencheng-story.html，自包含 HTML，入口在 pages/story/story.html）。
- **生成你的面具**：MBTI 式人格测试已接入（pages/quiz/quiz.html，题库 10 题 × 6 选项，6 种面具人格 + 面具实拍图结果）。
- **历史展厅**：已按《藏戏面具历史展厅解说词》完整布展（hall 主视觉导览 / origin 面具初相双图 / process 发展过程时间轴 7 节点 / meaning 雪顿节活态传承 / conclusion 结语三段升华），7 张解说配图在 assets/images/history/。
- **图片灯箱**：图片展示页点击图片放大，ESC / 点击关闭。

## 后续扩展

- **换板块配图（原创 IP）**：编辑 `js/curtain.js` 中 sections 数组的 `img` 字段。
- **换图片**：放入 `assets/images/`，替换对应 HTML 中的 `src`。
- **换视频 / 模型**：放入 `assets/videos|models/`，在 `*-model.html` 对应占位区接入。
- **换 PPT**：放入 `assets/ppt/`，或在 `story.html` 中改链接。
- **补充游戏**：在 `pages/game/nurture.html` 的 `#game-container` 粘贴。
- **补充测试**：在 `pages/quiz/quiz.html` 的 `#quiz-container` 粘贴。
- **改面具数据**：编辑 `js/data/masks.js`（名称、颜色、链接）。

## 说明

- 面具名称（温巴 / 兽纹 / 云雷 / 流金 / 墨影 / 赤焰 / 玄青）为**占位名称**，
  请在 `js/data/masks.js` 中改为实际面具。
- 所有占位内容均以 `<!-- 占位：... -->` 注释标注。
- 子页面使用「根相对路径 + <base>」，本地打开与在线发布均正常。
